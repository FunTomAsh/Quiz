package com.example.quiz;

public class Topic {
    private Temat temat;

    public Temat getTemat() {
        return temat;
    }
}
