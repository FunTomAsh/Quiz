package com.example.quiz;

import java.util.ArrayList;

public class Odpowiedz {

    private String odp;

    public String getOdp() {
        return odp;
    }

}
