package com.example.quiz;

import java.util.ArrayList;
import java.util.List;

public class QuizTopic {
    private List<Topic> quiz;

    public List<Topic> getQuiz() {
        return quiz;
    }

}