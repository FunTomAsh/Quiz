package com.example.quiz;

import java.util.List;

public class Pytania {

    private Pytanie pytanie;

    public Pytanie getPytanie() {
        return pytanie;
    }
}
